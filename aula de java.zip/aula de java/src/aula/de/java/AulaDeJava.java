/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package aula.de.java;

/**
 *
 * @author joao.gssilva9
 */
public class AulaDeJava {
 public static void frase(){
   System.out.println("imprimindo usando função");  
     
     
 }
 public static void frase2(){
     System.out.println("arabe");
 }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        frase2();
        frase2();
        frase();
        
    }
    
}
